#import <Flutter/Flutter.h>

@interface CunningDocumentScannerPlugin : NSObject<FlutterPlugin>
@end
