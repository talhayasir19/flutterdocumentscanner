## 1.1.2
* iOS return unique filenames

## 1.1.1
* Updated android documentscanner library

## 1.1.0
* Exchanged android documentscanner with https://github.com/WebsiteBeaver/android-document-scanner

## 1.0.4
* Fixed conflicting requestcodes issue

## 1.0.3
* Updated permission handler constraint to ^10
* Android fixed nullsafe access issues

## 1.0.2
* Cleanup code - added images to README.md

## 1.0.1

* Fixed Playstore issue exported activity. Added documentation.

## 1.0.0

* Android and iOs Documentscanner based on Visionkit and AndroidDocument https://github.com/mayuce/AndroidDocumentScanner
