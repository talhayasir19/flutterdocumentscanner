package biz.cunning.cunning_document_scanner_example

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
